--Add Playermodel
player_manager.AddValidModel( "Kinugawa Kasumi", "models/rebirthlabs/bluearchive/kinugawa_kasumi/kinugawa_kasumi.mdl" )